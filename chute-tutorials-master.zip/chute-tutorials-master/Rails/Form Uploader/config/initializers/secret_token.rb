# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Testapp::Application.config.secret_token = 'a7d1e615c8b86628376d5882879072995f3028e5206e641c9cb3c9e11155c2e73a5ff4fda2e838f766933a436f72c8c268c20c47f515fa45902171bdcf2aca2a'
