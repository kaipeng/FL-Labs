# Form Uploader Tutorial

## Overview

This Tutorial shows you how to upload files directly from your Rails application to Chute.

## Setup
1. [Sign up](http://getchute.com) for a Chute Developer Account
2. Create a [New App](http://apps.getchute.com)
3. Customize your App credentials in `app/controllers/users_controller.rb`