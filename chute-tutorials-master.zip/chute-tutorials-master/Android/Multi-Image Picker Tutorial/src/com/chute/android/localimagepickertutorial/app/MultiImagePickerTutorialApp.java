package com.chute.android.localimagepickertutorial.app;

import com.chute.android.multiimagepicker.app.MultiImagePickerApp;

public class MultiImagePickerTutorialApp extends MultiImagePickerApp {

	public static final String TAG = MultiImagePickerTutorialApp.class.getSimpleName();
}
