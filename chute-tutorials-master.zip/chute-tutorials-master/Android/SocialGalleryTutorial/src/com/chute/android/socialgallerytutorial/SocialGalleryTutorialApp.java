package com.chute.android.socialgallerytutorial;

import com.chute.android.socialgallery.app.SocialGalleryApp;

public class SocialGalleryTutorialApp extends SocialGalleryApp {

	public static final String TAG = SocialGalleryTutorialApp.class
			.getSimpleName();
}
