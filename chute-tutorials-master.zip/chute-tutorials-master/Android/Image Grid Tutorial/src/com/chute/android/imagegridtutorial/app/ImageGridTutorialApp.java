package com.chute.android.imagegridtutorial.app;

import com.chute.android.imagegrid.app.ImageGridApp;

public class ImageGridTutorialApp extends ImageGridApp {

	public static final String TAG = ImageGridTutorialApp.class.getSimpleName();
}
