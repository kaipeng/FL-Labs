package com.chute.android.commentstutorial;

import com.chute.android.comments.app.PhotoCommentsApp;


public class PhotoCommentsTutorialApp extends PhotoCommentsApp {

	public static final String TAG = PhotoCommentsTutorialApp.class.getSimpleName();
}
