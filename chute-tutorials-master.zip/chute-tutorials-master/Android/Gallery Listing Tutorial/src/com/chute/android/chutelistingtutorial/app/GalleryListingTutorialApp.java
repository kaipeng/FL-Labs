package com.chute.android.chutelistingtutorial.app;

import com.chute.android.gcchutelisting.app.GalleryListingApp;


public class GalleryListingTutorialApp extends GalleryListingApp {

	public static final String TAG = GalleryListingTutorialApp.class
			.getSimpleName();
}
