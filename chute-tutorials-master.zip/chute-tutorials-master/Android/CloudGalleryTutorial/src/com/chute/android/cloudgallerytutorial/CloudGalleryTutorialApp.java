package com.chute.android.cloudgallerytutorial;

import com.chute.android.gallery.ui.CloudGalleryApp;

public class CloudGalleryTutorialApp extends CloudGalleryApp {

	public static final String TAG = CloudGalleryTutorialApp.class
			.getSimpleName();
	
}
