package com.chute.android.shareviewtutorial;

import com.chute.android.imagesharer.app.ImageSharerApp;


public class ShareViewTutorialApp extends ImageSharerApp {

	public static final String TAG = ShareViewTutorialApp.class.getSimpleName();
}
