package com.chute.android.createchutetutorial;

public class Constants {

	public static final String TAG = Constants.class.getSimpleName();
	
	public static final String BASIC_CHUTE_NAME = "Basic Chute";
	public static final String PASSWORD_CHUTE_NAME = "Password Chute";
	public static final String PERMISSIONS_CHUTE_NAME = "Permissions Chute";
	public static final String PASSWORD = "Password";
}
