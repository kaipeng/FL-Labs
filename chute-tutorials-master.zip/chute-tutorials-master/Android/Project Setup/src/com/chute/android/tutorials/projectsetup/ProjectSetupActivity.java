package com.chute.android.tutorials.projectsetup;

import android.app.Activity;
import android.os.Bundle;

public class ProjectSetupActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.main);

	// Nothing here, just see the library dependencies and the
	// AndroidManifest.xml for permissions and declarations
    }
}