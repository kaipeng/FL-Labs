//
//  GCComment.h
//  ChuteSDKDevProject
//
//  Created by Brandon Coston on 9/9/11.
//  Copyright 2011 Chute Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GetChute.h"

@interface GCComment : GCResource{
    
}

-(GCChute*)chute;


@end
