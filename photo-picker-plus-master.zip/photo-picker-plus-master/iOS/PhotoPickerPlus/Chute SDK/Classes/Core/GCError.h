//
//  GCError.h
//
//  Created by Achal Aggarwal on 02/09/11.
//  Copyright 2011 Chute Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GCError : NSError

@end
