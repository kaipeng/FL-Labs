//
//  NewViewController.h
//  JTRevealSidebarDemo
//
//  Created by James Apple Tang on 12/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewViewController : UIViewController

@property (nonatomic, strong) UILabel     *label;
@property (nonatomic, strong) UITableView *rightSidebarView;

@end
