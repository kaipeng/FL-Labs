//
//  JTRevealSidebarDemoV2Tests.h
//  JTRevealSidebarDemoV2Tests
//
//  Created by James Apple Tang on 7/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface JTRevealSidebarDemoV2Tests : SenTestCase

@end
