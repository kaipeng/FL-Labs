//
//  JTRevealSidebarDemoV2Tests.m
//  JTRevealSidebarDemoV2Tests
//
//  Created by James Apple Tang on 7/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "JTRevealSidebarDemoV2Tests.h"

@implementation JTRevealSidebarDemoV2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in JTRevealSidebarDemoV2Tests");
}

@end
