//
//  JTRevealSidebarDemoTests.h
//  JTRevealSidebarDemoTests
//
//  Created by james on 10/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface JTRevealSidebarDemoTests : SenTestCase

@end
