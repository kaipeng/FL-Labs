//
//  JTRevealSidebarDemoTests.m
//  JTRevealSidebarDemoTests
//
//  Created by james on 10/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "JTRevealSidebarDemoTests.h"

@implementation JTRevealSidebarDemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in JTRevealSidebarDemoTests");
}

@end
